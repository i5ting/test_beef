//
//  NewHandScroll.h
//  SinaNews
//
//  Created by shieh exbice on 12-1-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewHandScroll : UIScrollView{
    
}

@property(nonatomic,assign)BOOL scaleModeFit;

@end
