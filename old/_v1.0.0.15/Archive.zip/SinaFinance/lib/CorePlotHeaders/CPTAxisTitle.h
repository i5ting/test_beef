
#import <Foundation/Foundation.h>
#import "CPTAxisLabel.h"


@interface CPTAxisTitle : CPTAxisLabel {

}

@end
