#import "CPTTheme.h"

@interface _CPTXYTheme : CPTTheme {

}

@end
