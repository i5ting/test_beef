/*
 *  QuartzUtils.h
 *  TwitterFon
 *
 *  Created by kaz on 11/17/08.
 *  Copyright 2008 naan studio. All rights reserved.
 *
 */

#include <QuartzCore/QuartzCore.h>

void drawRoundedRect(CGContextRef context, CGRect rrect);