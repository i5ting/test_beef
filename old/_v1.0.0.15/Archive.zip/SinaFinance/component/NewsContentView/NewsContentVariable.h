//
//  NewsContentVariable.h
//  SinaNews
//
//  Created by shieh exbice on 12-2-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef SinaNews_NewsContentVariable_h
#define SinaNews_NewsContentVariable_h

#define placeholder_photo	@"pic_item_loading.png"

#define GAPBETWEENCONTENTIMAGE 20
#define GAPBETWEENCONTENTVIDEO 20
#define GAPBETWEENCLICKURL 20
#define GAPBETWEENEXTRADATA 10
#define GAPBETWEENRELATIVEANDCOMMENT 0
#define GAPBETWEENCOMMENT 10
#define GAPBETWEENCONTENTSCROLLVIEW 10
#define SCROLLVIEWHEIGHT 380
#define SCROLLVIEWWIDTH 300
#define placeholder_photo_length	160
#define GAPBETWEENCONTENSEPRARATELINE 5
#define GAPBETWEENCONTENTITEM 10
#define IMAGESGAP 5
#define GAPBETWEENCONTENTPHOTOTEXT 10
#define GAPBETWEENCONTENTBUTTON 15
#define CLICKBUTTONHEIGHT 44
#define CONTENTCLICKURLHEIGHT 30
#define CONTENTCOPYRIGHTHEIGHT 0
#define PREDISPLAYWIDTH 1500

#define GAPBETWEENSCROLLVIEW 10
#define SCROLLVIEWLABLEHEIGHT 15

#define CONTENTPAGENUMHEIGHT 21

#define FONTINCREMENT 2

#define CurrentFontName @"Helvetica"
#define CurrentAirticleFontName @"Helvetica"

#define ACTIVEINDICATORWIDTH 30

#endif
