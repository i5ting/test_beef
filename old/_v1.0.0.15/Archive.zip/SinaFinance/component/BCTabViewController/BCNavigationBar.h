//
//  BCNavigationBar.h
//  SinaNews
//
//  Created by shieh exbice on 11-11-14.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BCNavigationBar : UIImageView
{
    
}

@end
