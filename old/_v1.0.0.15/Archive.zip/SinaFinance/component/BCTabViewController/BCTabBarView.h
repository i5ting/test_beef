@class BCTabBar;

@interface BCTabBarView : UIView

@property (nonatomic, assign) UIView *contentView;
@property (nonatomic, assign) BCTabBar *tabBar;
@property (nonatomic, assign) BOOL showFullZone;


@end
