//
//  DataButton.m
//  SinaFinance
//
//  Created by shieh exbice on 12-3-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "DataButton.h"

@implementation DataButton

@synthesize data;

-(void)dealloc
{
    [data release];
    
    [super dealloc];
}

@end
