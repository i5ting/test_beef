//
//	 ______    ______    ______    
//	/\  __ \  /\  ___\  /\  ___\   
//	\ \  __<  \ \  __\_ \ \  __\_ 
//	 \ \_____\ \ \_____\ \ \_____\ 
//	  \/_____/  \/_____/  \/_____/ 
//
//	Copyright (c) 2012 BEE creators
//	http://www.whatsbug.com
//
//	Permission is hereby granted, free of charge, to any person obtaining a
//	copy of this software and associated documentation files (the "Software"),
//	to deal in the Software without restriction, including without limitation
//	the rights to use, copy, modify, merge, publish, distribute, sublicense,
//	and/or sell copies of the Software, and to permit persons to whom the
//	Software is furnished to do so, subject to the following conditions:
//
//	The above copyright notice and this permission notice shall be included in
//	all copies or substantial portions of the Software.
//
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
//	IN THE SOFTWARE.
//
//
//  Bee_UIPullLoader.m
//

#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)

#import "Bee_Precompile.h"
#import "Bee_UIPullLoader.h"
#import "Bee_UIActivityIndicatorView.h"
#import "Bee_UISignal.h"
#import "UIView+BeeExtension.h"
#import "UIView+BeeUISignal.h"
#import "CGRect+BeeExtension.h"

#pragma mark -

#undef	ANIMATION_DURATION
#define ANIMATION_DURATION	(0.3f)

#pragma mark -

@interface BeeUIPullLoader(Private)
- (void)initSelf;
@end

@implementation BeeUIPullLoader

DEF_SIGNAL( STATE_CHANGED )
DEF_SIGNAL( FRAME_CHANGED )

DEF_INT( STATE_NORMAL,	0 )
DEF_INT( STATE_PULLING,	1 )
DEF_INT( STATE_LOADING,	2 )

@synthesize state = _state;

@dynamic normal;
@dynamic pulling;
@dynamic loading;

static Class	__defaultClass = nil;
static CGSize	__defaultSize = { 0 };

+ (void)setDefaultClass:(Class)clazz
{
	__defaultClass = clazz;
}

+ (void)setDefaultSize:(CGSize)size
{
	__defaultSize = size;
}

+ (BeeUIPullLoader *)spawn
{
	CGRect frame = CGSizeMakeBound(__defaultSize);
	
	if ( nil == __defaultClass )
	{
		return [[[BeeUIPullLoader alloc] initWithFrame:frame] autorelease];
	}
	else
	{
		return [[[__defaultClass alloc] initWithFrame:frame] autorelease];
	}
}

+ (BeeUIPullLoader *)spawn:(NSString *)tagString
{
	CGRect frame = CGSizeMakeBound(__defaultSize);
	
	if ( nil == __defaultClass )
	{
		BeeUIPullLoader * view = [[[BeeUIPullLoader alloc] initWithFrame:frame] autorelease];
		view.tagString = tagString;
		return view;
	}
	else
	{
		BeeUIPullLoader * view = [[[__defaultClass alloc] initWithFrame:frame] autorelease];
		view.tagString = tagString;
		return view;
	}
}

- (id)init
{
	self = [super init];
	if ( self )
	{
		[self initSelf];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if ( self )
	{
		[self initSelf];
		[self changeFrame:frame];
    }
    return self;
}

- (void)initSelf
{
	self.backgroundColor = [UIColor clearColor];
//	self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	
	_state = BeeUIPullLoader.STATE_NORMAL;
	_inited = YES;

	[self load];
}

- (void)changeFrame:(CGRect)frame
{
	if ( _inited )
	{
		[self sendUISignal:self.FRAME_CHANGED];
	}
}

- (void)setFrame:(CGRect)frame
{
	if ( NO == CGRectEqualToRect( self.frame, frame ) )
	{
		[super setFrame:frame];
		[self changeFrame:frame];
	}
}

- (void)dealloc
{
	[self unload];
	
    [super dealloc];
}

- (BOOL)normal
{
	return (BeeUIPullLoader.STATE_NORMAL == _state) ? YES : NO;
}

- (void)setNormal:(BOOL)flag
{
	if ( flag )
	{
		[self changeState:BeeUIPullLoader.STATE_NORMAL];		
	}
}

- (BOOL)pulling
{
	return (BeeUIPullLoader.STATE_PULLING == _state) ? YES : NO;
}

- (void)setPulling:(BOOL)flag
{
	if ( flag )
	{
		[self changeState:BeeUIPullLoader.STATE_PULLING];		
	}
}

- (BOOL)loading
{
	return (BeeUIPullLoader.STATE_LOADING == _state) ? YES : NO;
}

- (void)setLoading:(BOOL)flag
{
	if ( flag )
	{
		[self changeState:BeeUIPullLoader.STATE_LOADING];
	}
}

- (void)changeState:(NSInteger)state
{
	[self changeState:state animated:NO];
}

- (void)changeState:(NSInteger)state animated:(BOOL)animated
{
	if ( NO == _inited || _state == state )
		return;

	_state = state;

	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:(animated ? ANIMATION_DURATION : 0.001f)];
	[UIView setAnimationBeginsFromCurrentState:YES];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop)];

	[self sendUISignal:self.STATE_CHANGED];

	[UIView commitAnimations];
}

- (void)animationDidStop
{
	// TODO:
}

@end

#endif	// #if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
