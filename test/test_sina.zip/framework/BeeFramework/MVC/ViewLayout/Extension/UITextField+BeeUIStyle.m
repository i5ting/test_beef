//
//	 ______    ______    ______
//	/\  __ \  /\  ___\  /\  ___\
//	\ \  __<  \ \  __\_ \ \  __\_
//	 \ \_____\ \ \_____\ \ \_____\
//	  \/_____/  \/_____/  \/_____/
//
//	Copyright (c) 2012 BEE creators
//	http://www.whatsbug.com
//
//	Permission is hereby granted, free of charge, to any person obtaining a
//	copy of this software and associated documentation files (the "Software"),
//	to deal in the Software without restriction, including without limitation
//	the rights to use, copy, modify, merge, publish, distribute, sublicense,
//	and/or sell copies of the Software, and to permit persons to whom the
//	Software is furnished to do so, subject to the following conditions:
//
//	The above copyright notice and this permission notice shall be included in
//	all copies or substantial portions of the Software.
//
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//	FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
//	IN THE SOFTWARE.
//
//
//  UITextField+BeeUIStyle.m
//

#if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)

#import "UITextField+BeeUIStyle.h"
#import "UIView+BeeUIStyle.h"
#import "NSDictionary+BeeExtension.h"

#import <objc/runtime.h>
#import <objc/message.h>

@implementation UITextField (BeeUIStyle)

- (void)applyStyleProperties:(NSDictionary *)properties
{
    [super applyStyleProperties:properties];
    
    NSString * placeholder = [properties stringOfAny:@[@"default", @"placeholder", @"placeHolder", @"place-holder"]];
    if ( placeholder )
    {
        [self setPlaceholder:placeholder];
    }

    NSString * returnType = [properties stringOfAny:@[@"return", @"return-type", @"returnType", @"returnKeyType", @"return-key-type"]];
    if ( returnType )
    {
        if ( NSOrderedSame == [returnType compare:@"Done" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeyDone];
        }
        else if ( NSOrderedSame == [returnType compare:@"Search" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeySearch];
        }
        else if ( NSOrderedSame == [returnType compare:@"Join" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeyJoin];
        }
        else if ( NSOrderedSame == [returnType compare:@"Send" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeySend];
        }
        else if ( NSOrderedSame == [returnType compare:@"Next" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeyNext];
        }
        else if ( NSOrderedSame == [returnType compare:@"Go" options:NSCaseInsensitiveSearch] )
        {
            [self setReturnKeyType:UIReturnKeyGo];
        }
    }

    NSString * keyboardType = [properties stringOfAny:@[@"key", @"keyboard", @"keyboardType", @"keypad", @"keypadType", @"inputMethod", @"input-method", @"ime"]];
    if ( keyboardType )
    {
        if ( NSOrderedSame == [keyboardType compare:@"default" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeDefault];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"ascii" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"abc" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeASCIICapable];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"number" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"123" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeNumbersAndPunctuation];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"pin" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeNumberPad];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"phone" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"call" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypePhonePad];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"phone" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"call" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypePhonePad];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"name" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"contact" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeNamePhonePad];
		}
        else if ( NSOrderedSame == [keyboardType compare:@"email" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"mail" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [keyboardType compare:@"@" options:NSCaseInsensitiveSearch] )
        {
			[self setKeyboardType:UIKeyboardTypeEmailAddress];
		}
	}

    NSString * capType = [properties stringOfAny:@[@"cap", @"cap-type", @"capType", @"autocapitalizationType"]];
    if ( capType )
    {
        if ( NSOrderedSame == [capType compare:@"words" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocapitalizationType:UITextAutocapitalizationTypeWords];
		}
        else if ( NSOrderedSame == [capType compare:@"sentences" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocapitalizationType:UITextAutocapitalizationTypeSentences];
		}
        else if ( NSOrderedSame == [capType compare:@"all" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [capType compare:@"allChars" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [capType compare:@"allCharacters" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [capType compare:@"all-chars" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [capType compare:@"all-characters" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocapitalizationType:UITextAutocapitalizationTypeAllCharacters];
		}
        else if ( NSOrderedSame == [capType compare:@"none" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocapitalizationType:UITextAutocapitalizationTypeNone];
		}
	}
    
    NSString * corType = [properties stringOfAny:@[@"cor", @"correction", @"correction-type", @"cor-type", @"corType", @"autocorrectionType"]];
    if ( corType )
    {
        if ( NSOrderedSame == [corType compare:@"true" options:NSCaseInsensitiveSearch] ||
			NSOrderedSame == [corType compare:@"yes" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocorrectionType:UITextAutocorrectionTypeYes];
		}
        else if ( NSOrderedSame == [corType compare:@"false" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [corType compare:@"no" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocorrectionType:UITextAutocorrectionTypeNo];
		}
        else if ( NSOrderedSame == [corType compare:@"default" options:NSCaseInsensitiveSearch] )
        {
			[self setAutocorrectionType:UITextAutocorrectionTypeDefault];
		}
	}
    
    NSString * secure = [properties stringOfAny:@[@"sec", @"secure", @"password"]];
    if ( secure )
    {
		if ( NSOrderedSame == [secure compare:@"true" options:NSCaseInsensitiveSearch] ||
			NSOrderedSame == [secure compare:@"yes" options:NSCaseInsensitiveSearch] )
        {
			[self setSecureTextEntry:YES];
		}
		else
		{
			[self setSecureTextEntry:NO];
		}
	}
	
    NSString * borderStyle = [properties stringOfAny:@[@"border", @"borderStyle", @"border-style"]];
    if ( borderStyle )
    {
        if ( NSOrderedSame == [borderStyle compare:@"None" options:NSCaseInsensitiveSearch] )
        {
            [self setBorderStyle:UITextBorderStyleNone];
        }
        else if ( NSOrderedSame == [borderStyle compare:@"Line" options:NSCaseInsensitiveSearch] )
        {
            [self setBorderStyle:UITextBorderStyleLine];
        }
        else if ( NSOrderedSame == [borderStyle compare:@"Bezel" options:NSCaseInsensitiveSearch] )
        {
            [self setBorderStyle:UITextBorderStyleBezel];
        }
        else if ( NSOrderedSame == [borderStyle compare:@"rounded" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [borderStyle compare:@"rounded-rect" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [borderStyle compare:@"RoundedRect" options:NSCaseInsensitiveSearch] )
        {
            [self setBorderStyle:UITextBorderStyleRoundedRect];
        }
    }
	
	NSString * clear = [properties stringOfAny:@[@"clear", @"clearButton", @"clearButtonMode", @"clear-button", @"clear-button-mode"]];
    if ( clear )
    {
		if ( NSOrderedSame == [clear compare:@"never" options:NSCaseInsensitiveSearch] )
		{
			self.clearButtonMode = UITextFieldViewModeNever;
		}
		else if ( NSOrderedSame == [clear compare:@"editing" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [clear compare:@"whileEditing" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [clear compare:@"while-editing" options:NSCaseInsensitiveSearch] )
		{
			self.clearButtonMode = UITextFieldViewModeWhileEditing;
		}
		else if ( NSOrderedSame == [clear compare:@"notEditing" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [clear compare:@"unlessEditing" options:NSCaseInsensitiveSearch] ||
				 NSOrderedSame == [clear compare:@"unless-editing" options:NSCaseInsensitiveSearch] )
		{
			self.clearButtonMode = UITextFieldViewModeUnlessEditing;
		}
		else if ( NSOrderedSame == [clear compare:@"always" options:NSCaseInsensitiveSearch] )
		{
			self.clearButtonMode = UITextFieldViewModeAlways;
		}
	}

	if ( [self respondsToSelector:@selector(setMaxLength:)] )
	{
		NSString * maxLength = [properties stringOfAny:@[@"limit",@"max", @"maxLength", @"max-length"]];
		if ( maxLength )
		{
			objc_msgSend( self, @selector(setMaxLength:), maxLength.integerValue );
		}
	}
}

+ (BOOL)supportForSizeEstimating
{
	return NO;
}

@end

#endif	// #if (TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR)
