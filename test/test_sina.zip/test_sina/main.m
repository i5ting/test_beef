//
//  main.m
//  test_sina
//
//  Created by kwoe gavin on 13-5-13.
//  Copyright (c) 2013年 geek-zoo studio. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
