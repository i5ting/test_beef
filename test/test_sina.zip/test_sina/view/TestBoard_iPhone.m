//
//  TestBoard_iPhone.m
//

#import "TestBoard_iPhone.h"

#pragma mark -

@implementation Title_iPhone

DEF_SIGNAL(TOUCHED)

- (void)load
{
	[super load];

	self.tappable = YES;
	self.tapSignal = self.TOUCHED;
}

- (void)unload
{
	[super unload];
}

- (void)dataDidChanged
{
	$(@"name").TEXT( @"广州药业" );
	$(@"code").TEXT( @"(600332)" );
}

@end

#pragma mark -

@implementation Section1_iPhone

DEF_SIGNAL(TOUCHED)

- (void)load
{
	[super load];
	
	self.tappable = YES;
	self.tapSignal = self.TOUCHED;
}

- (void)unload
{
	[super unload];
}

- (void)dataDidChanged
{
	$(@"point-text").TEXT( @"34.08" );
	$(@"grow-point").TEXT( @"+3.10" );
	$(@"grow-percent").TEXT( @"+10.01%" );
	
	$(@"line2-1").TEXT( @"今开: 171.80" );
	$(@"line2-2").TEXT( @"昨收: 171.11" );
	$(@"line2-3").TEXT( @"最高: 174.02" );
	$(@"line3-1").TEXT( @"最低: 276.35" );
	$(@"line3-2").TEXT( @"成交量: 1.48万手" );
	$(@"line3-3").TEXT( @"换手率: 0.14%" );
	$(@"line4-1").TEXT( @"市盈率: 123.89" );
	$(@"line4-2").TEXT( @"流通市值: 1796.35亿" );
	
	$(@"photo").IMAGE( @"empty.png" );
}

@end

#pragma mark -

@implementation Section2_iPhone

DEF_SIGNAL(TOUCHED)

- (void)load
{
	[super load];

	self.tappable = YES;
	self.tapSignal = self.TOUCHED;
	
//	[self hintAllSubviews];
}

- (void)unload
{
	[super unload];
}

- (void)dataDidChanged
{
	$(@"title-text").TEXT( @"热股点评" );
	$(@"line2-1").TEXT( @"[置顶] 广药王老吉下一步规划破产" );	
	$(@"line3-1").TEXT( @"最后回复: %@", @"12:43" );
	$(@"line3-2").TEXT( @"新闻来源: %@", @"77" );
	$(@"line3-3").TEXT( @"回复: %@", @"55" );
	$(@"line4-1").TEXT( @"内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容内容" );
}

@end

#pragma mark -

@implementation TestBoard_iPhone

- (void)load
{
	[super load];
}

- (void)unload
{
	[super unload];
}

#pragma mark -

- (void)handleUISignal_BeeUIBoard:(BeeUISignal *)signal
{
	[super handleUISignal:signal];
	
	if ( [signal is:BeeUIBoard.CREATE_VIEWS] )
	{
        self.view.backgroundColor = [UIColor grayColor];

        [self showNavigationBarAnimated:NO];
        [self showBarButton:UINavigationBar.BARBUTTON_LEFT title:@"back"];
		[self showBarButton:UINavigationBar.BARBUTTON_RIGHT title:@"search"];

		_titleCell = [[Title_iPhone alloc] init];
		self.titleView = _titleCell;

        _scroll = [[BeeUILayoutScrollView alloc] initWithFrame:CGRectZero];
		[_scroll setDataSource:self];
        [self.view addSubview:_scroll];
	}
	else if ( [signal is:BeeUIBoard.LAYOUT_VIEWS] )
	{
        _scroll.frame = self.viewBound;
		_titleCell.frame = CGRectMakeBound( 200, 44 );
	}
	else if ( [signal is:BeeUIBoard.DELETE_VIEWS] )
	{
		[self unobserveAllNotifications];
		
        [_scroll cancelReloadData];

        SAFE_RELEASE_SUBVIEW( _scroll );
        SAFE_RELEASE_SUBVIEW( _titleCell );
		
		self.titleView = nil;
	}
	else if ( [signal is:BeeUIBoard.LOAD_DATAS] )
	{
	}
	else if ( [signal is:BeeUIBoard.FREE_DATAS] )
	{
	}
	else if ( [signal is:BeeUIBoard.WILL_APPEAR] )
	{
		_titleCell.cellData = nil;	// TODO: re-fill data

		[_scroll syncReloadData];
	}
    else if ( [signal is:BeeUIBoard.DID_APPEAR] )
    {
    }
}

- (void)handleUISignal_UINavigationBar:(BeeUISignal *)signal
{
	[super handleUISignal:signal];
	
	if ( [signal is:UINavigationBar.BARBUTTON_LEFT_TOUCHED] )
	{
        // TODO:
	}
}

#pragma mark -

- (NSInteger)numberOfLinesInScrollView:(BeeUIScrollView *)scrollView
{
	return 1;
}

- (NSInteger)numberOfViewsInScrollView:(BeeUIScrollView *)scrollView
{
	return 5;
}

- (UIView *)scrollView:(BeeUIScrollView *)scrollView viewForIndex:(NSInteger)index scale:(CGFloat)scale
{
	if ( 0 == index )
	{
		Section1_iPhone * cell = [scrollView dequeueWithContentClass:[Section1_iPhone class]];
		cell.cellData = nil;	// TODO: re-fill data
		return cell;
	}
	else
	{
		Section2_iPhone * cell = [scrollView dequeueWithContentClass:[Section2_iPhone class]];
		cell.cellData = nil;	// TODO: re-fill data
		return cell;		
	}
}

- (CGSize)scrollView:(BeeUIScrollView *)scrollView sizeForIndex:(NSInteger)index
{
	if ( 0 == index )
	{
		return [Section1_iPhone sizeInBound:scrollView.bounds.size forData:nil];
	}
	else
	{
		return [Section2_iPhone sizeInBound:scrollView.bounds.size forData:nil];
	}
}

@end
