//
//  TestBoard_iPhone.h
//

#import "Bee.h"

#pragma mark -

@interface Title_iPhone : BeeUILayoutGridCell
AS_SIGNAL(TOUCHED)
@end

#pragma mark -

@interface Section1_iPhone : BeeUILayoutGridCell
AS_SIGNAL(TOUCHED)
@end

#pragma mark -

@interface Section2_iPhone : BeeUILayoutGridCell
AS_SIGNAL(TOUCHED)
@end

#pragma mark -

@interface TestBoard_iPhone : BeeUIBoard
{
	Title_iPhone *			_titleCell;
    BeeUILayoutScrollView *	_scroll;
}
@end
